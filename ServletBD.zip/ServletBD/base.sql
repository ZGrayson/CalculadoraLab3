create database Servlet;
use Servlet;
create table datos(nom varchar(50),pas varchar(50));
insert into datos values('Zyan','123'); 
select*from datos;